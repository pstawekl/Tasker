export type TaskTag = {
  task_id: number;
  tag_id: number;
};

export type TaskTags = TaskTag[];
