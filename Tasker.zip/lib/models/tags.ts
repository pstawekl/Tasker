export type Tag = {
  id: number;
  name: string;
};

export type Tags = Tag[];
