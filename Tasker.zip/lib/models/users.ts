export type User = {
  id: '';
  email: '';
  username: '';
  created_at: '';
  picture?: '';
};

export type Users = User[];
