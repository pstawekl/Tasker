export type Order = {
    or_id: number;
    or_vt_id: number;
    vt_name: string;
    or_start_date: string;
    or_return_date: string;
    or_user_id: number;
    is_returned: boolean;
}